void setup() {
  // put your setup code here, to run once
  Serial.begin(115200);
  Serial.println("Hello, ESP32");

  pinMode(21, OUTPUT); //lampu merah
  pinMode(5, OUTPUT); // lampu kuning
  pinMode(2, OUTPUT); // lampu hijau
}

void loop() { // lampu merah menyala selama 5 detik
  digitalWrite(21, HIGH);
  delay(5000); 
  digitalWrite(21, LOW);

  digitalWrite(5, HIGH); //lampu kuning menyala selama 3 detik
  delay(3000);
  digitalWrite(5, LOW);

  digitalWrite(2, HIGH); // lampu hijau menyala selama 6 detik
  delay(6000); // 
  digitalWrite(2, LOW);
}
